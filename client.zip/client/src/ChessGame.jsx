import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess } from "chess.js";
import { evaluate } from "./game/engine.js";
import { sound } from "./game/sound.js";
import { api } from "./api.js";
import "./ChessGame.css";

const GLYPH = { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟︎" };
const PIECE_NAME = { k: "King", q: "Queen", r: "Rook", b: "Bishop", n: "Knight", p: "Pawn" };
const VALUE = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
const FILES = "abcdefgh";

const LEVELS = [
  { id: "easy", name: "Squire", note: "Forgiving. Makes human mistakes." },
  { id: "medium", name: "Knight", note: "Solid tactics. Punishes blunders." },
  { id: "hard", name: "Grandmaster", note: "Calculates deeply. Bring your best." },
];

function Piece({ piece, className = "", style }) {
  return (
    <span className={`piece piece-${piece.color} ${className}`} style={style} aria-hidden="true">
      {GLYPH[piece.type]}
    </span>
  );
}

function gameOverInfo(game, resigned) {
  if (resigned) {
    return { winner: resigned === "w" ? "b" : "w", reason: "resignation" };
  }
  if (game.isCheckmate()) return { winner: game.turn() === "w" ? "b" : "w", reason: "checkmate" };
  if (game.isStalemate()) return { winner: null, reason: "stalemate" };
  if (game.isInsufficientMaterial()) return { winner: null, reason: "insufficient material" };
  if (game.isThreefoldRepetition()) return { winner: null, reason: "threefold repetition" };
  if (game.isDraw()) return { winner: null, reason: "fifty-move rule" };
  return null;
}

/* ---------------- Setup screen ---------------- */

function Setup({ initial, onStart, onBack }) {
  const [mode, setMode] = useState(initial?.mode || "ai");
  const [difficulty, setDifficulty] = useState(initial?.difficulty || "medium");
  const [color, setColor] = useState(initial?.color || "w");

  return (
    <main className="chess-setup">
      <button className="chess-ghost back-link" onClick={onBack}>← Back</button>
      <div className="setup-head reveal-in">
        <p className="chess-eyebrow">PREPARE FOR BATTLE</p>
        <h1>Choose your <em>opponent.</em></h1>
      </div>

      <div className="setup-modes">
        <button className={`mode-card ${mode === "ai" ? "active" : ""}`} onClick={() => setMode("ai")}>
          <span className="mode-glyph">♛</span>
          <strong>Versus the Machine</strong>
          <small>Face the Arena engine at three levels of strength.</small>
        </button>
        <button className={`mode-card ${mode === "local" ? "active" : ""}`} onClick={() => setMode("local")}>
          <span className="mode-glyph">⚔</span>
          <strong>Local Duel</strong>
          <small>Two players, one board. Pass and play.</small>
        </button>
      </div>

      {mode === "ai" && (
        <div className="setup-options">
          <div>
            <p className="option-label">Difficulty</p>
            <div className="level-row">
              {LEVELS.map((level) => (
                <button key={level.id} className={`level ${difficulty === level.id ? "active" : ""}`} onClick={() => setDifficulty(level.id)}>
                  <strong>{level.name}</strong>
                  <small>{level.note}</small>
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="option-label">Play as</p>
            <div className="color-row">
              {[
                ["w", "White", "♔"],
                ["b", "Black", "♚"],
                ["r", "Random", "?"],
              ].map(([id, label, glyph]) => (
                <button key={id} className={`color-pick ${color === id ? "active" : ""}`} onClick={() => setColor(id)}>
                  <span>{glyph}</span>
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      <button
        className="chess-primary start-btn"
        onClick={() =>
          onStart({
            mode,
            difficulty,
            color: color === "r" ? (Math.random() < 0.5 ? "w" : "b") : color,
            pickedColor: color,
          })
        }
      >
        Enter the board
      </button>
    </main>
  );
}

/* ---------------- Match ---------------- */

function Match({ config, token, onBack, onNewSetup, onSaved }) {
  const { mode, difficulty } = config;
  const playerColor = mode === "ai" ? config.color : null;

  const [fen, setFen] = useState(() => new Chess().fen());
  const [history, setHistory] = useState([]); // verbose moves
  const [selected, setSelected] = useState(null);
  const [promotion, setPromotion] = useState(null);
  const [flipped, setFlipped] = useState(playerColor === "b");
  const [thinking, setThinking] = useState(false);
  const [resigned, setResigned] = useState(null);
  const [hint, setHint] = useState(null);
  const [muted, setMuted] = useState(sound.isMuted());
  const [saveState, setSaveState] = useState("");
  const [overlayOpen, setOverlayOpen] = useState(true);
  const [dragFrom, setDragFrom] = useState(null);

  const workerRef = useRef(null);
  const requestRef = useRef(0);
  const savedRef = useRef(false);
  const fenRef = useRef(fen);
  useEffect(() => {
    fenRef.current = fen;
  }, [fen]);

  const game = useMemo(() => {
    const g = new Chess();
    for (const m of history) g.move({ from: m.from, to: m.to, promotion: m.promotion });
    return g;
  }, [history]);

  const board = game.board();
  const turn = game.turn();
  const over = gameOverInfo(game, resigned);
  const lastMove = history[history.length - 1];
  const isPlayersTurn = mode === "local" || turn === playerColor;
  const locked = Boolean(over) || thinking || !isPlayersTurn || Boolean(promotion);

  // Start a worker for the engine.
  useEffect(() => {
    const worker = new Worker(new URL("./game/engine.worker.js", import.meta.url), { type: "module" });
    workerRef.current = worker;
    sound.start();
    return () => worker.terminate();
  }, []);

  const askEngine = useCallback((position, level) => {
    return new Promise((resolve) => {
      const worker = workerRef.current;
      if (!worker) return resolve(null);
      const id = ++requestRef.current;
      const handler = (event) => {
        if (event.data.id !== id) return;
        worker.removeEventListener("message", handler);
        resolve(event.data.move);
      };
      worker.addEventListener("message", handler);
      worker.postMessage({ id, fen: position, level });
    });
  }, []);

  const commit = useCallback(
    (move) => {
      const next = new Chess(fen);
      let played;
      try {
        played = next.move(move);
      } catch {
        return false;
      }
      if (!played) return false;
      if (next.isCheck()) sound.check();
      else if (played.captured) sound.capture();
      else sound.move();
      setFen(next.fen());
      setHistory((h) => [...h, played]);
      setSelected(null);
      setPromotion(null);
      setHint(null);
      return true;
    },
    [fen]
  );

  // Engine reply.
  useEffect(() => {
    if (mode !== "ai" || over || turn === playerColor) return;
    let cancelled = false;
    setThinking(true);
    const started = Date.now();
    askEngine(fen, difficulty).then((move) => {
      const wait = Math.max(0, 450 - (Date.now() - started)); // a breath before it strikes
      setTimeout(() => {
        if (cancelled) return;
        setThinking(false);
        if (move) commit(move);
      }, wait);
    });
    return () => {
      cancelled = true;
      setThinking(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fen, mode, playerColor, difficulty]);

  // Save the finished game.
  useEffect(() => {
    if (!over || savedRef.current) return;
    savedRef.current = true;
    const won = mode === "ai" ? over.winner === playerColor : true;
    sound.end(over.winner ? won : true);
    if (!token) return;
    const result =
      mode === "ai"
        ? over.winner === null
          ? "draw"
          : over.winner === playerColor
            ? "win"
            : "loss"
        : over.winner === null
          ? "draw"
          : over.winner === "w"
            ? "white"
            : "black";
    setSaveState("saving");
    api("/games", {
      method: "POST",
      token,
      body: {
        mode,
        difficulty: mode === "ai" ? difficulty : undefined,
        playerColor: mode === "ai" ? playerColor : undefined,
        result,
        reason: over.reason,
        moves: history.length,
        pgn: game.pgn().slice(0, 6000),
      },
    })
      .then(() => {
        setSaveState("saved");
        onSaved?.();
      })
      .catch(() => setSaveState("error"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [over?.reason]);

  const legalTargets = useMemo(() => {
    if (!selected) return new Map();
    return new Map(game.moves({ square: selected, verbose: true }).map((m) => [m.to, m]));
  }, [selected, game]);

  function tryMove(from, to) {
    const legal = game.moves({ square: from, verbose: true }).find((m) => m.to === to);
    if (!legal) return false;
    if (legal.flags.includes("p")) {
      setPromotion({ from, to });
      return true;
    }
    return commit({ from, to });
  }

  function onSquare(square) {
    if (locked) return;
    const piece = game.get(square);
    if (selected && selected !== square && tryMove(selected, square)) return;
    if (piece && piece.color === turn) setSelected(square === selected ? null : square);
    else setSelected(null);
  }

  function undo() {
    if (!history.length || thinking) return;
    // Against the engine, take back a full turn (yours + its reply).
    let steps = 1;
    if (mode === "ai") steps = turn === playerColor ? 2 : 1;
    const next = history.slice(0, Math.max(0, history.length - steps));
    const g = new Chess();
    next.forEach((m) => g.move({ from: m.from, to: m.to, promotion: m.promotion }));
    setHistory(next);
    setFen(g.fen());
    setSelected(null);
    setPromotion(null);
    setHint(null);
  }

  function restart() {
    setHistory([]);
    setFen(new Chess().fen());
    setSelected(null);
    setPromotion(null);
    setResigned(null);
    setHint(null);
    setSaveState("");
    setOverlayOpen(true);
    savedRef.current = false;
    sound.start();
  }

  async function showHint() {
    if (locked) return;
    const asked = fen;
    setHint({ loading: true });
    const move = await askEngine(fen, "medium");
    if (fenRef.current !== asked) return;
    setHint(move ? { from: move.from, to: move.to, san: move.san } : null);
  }

  // Captured material.
  const captured = { w: [], b: [] }; // pieces captured BY that color
  for (const m of history) if (m.captured) captured[m.color].push(m.captured);
  const order = "qrbnp";
  captured.w.sort((a, b) => order.indexOf(a) - order.indexOf(b));
  captured.b.sort((a, b) => order.indexOf(a) - order.indexOf(b));
  const material = (c) => captured[c].reduce((s, p) => s + VALUE[p], 0);
  const diff = material("w") - material("b");

  // Evaluation bar (static evaluation, White's view).
  const evalScore = over
    ? over.winner === "w" ? 2000 : over.winner === "b" ? -2000 : 0
    : evaluate(game);
  const whiteShare = Math.max(4, Math.min(96, 50 + 50 * Math.tanh(evalScore / 600)));
  const flipView = flipped;

  const kingInCheck = game.isCheck()
    ? board.flat().find((p) => p && p.type === "k" && p.color === turn)?.square
    : null;

  const rows = flipView ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];
  const cols = flipView ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];

  function displayPos(square) {
    const c = FILES.indexOf(square[0]);
    const r = 8 - Number(square[1]);
    return { x: cols.indexOf(c), y: rows.indexOf(r) };
  }

  const animOffset = lastMove
    ? (() => {
        const a = displayPos(lastMove.from);
        const b = displayPos(lastMove.to);
        return { "--dx": a.x - b.x, "--dy": a.y - b.y };
      })()
    : null;

  const topColor = flipView ? "w" : "b";
  const bottomColor = flipView ? "b" : "w";
  const nameFor = (c) => {
    if (mode === "local") return c === "w" ? "White" : "Black";
    return c === playerColor ? "You" : `Arena Engine · ${LEVELS.find((l) => l.id === difficulty)?.name}`;
  };

  let status;
  if (over) {
    status = over.winner ? `${over.winner === "w" ? "White" : "Black"} wins by ${over.reason}` : `Draw by ${over.reason}`;
  } else if (thinking) {
    status = "The engine is calculating…";
  } else {
    status = `${turn === "w" ? "White" : "Black"} to move${game.isCheck() ? " — Check!" : ""}`;
  }

  let overlayTitle = "";
  let overlaySub = "";
  if (over) {
    if (mode === "ai") {
      overlayTitle = over.winner === null ? "Stalemate of Wills" : over.winner === playerColor ? "Victory" : "Defeat";
      overlaySub =
        over.winner === null
          ? `The battle ends in a draw by ${over.reason}.`
          : over.winner === playerColor
            ? `You conquered the ${LEVELS.find((l) => l.id === difficulty)?.name} by ${over.reason}.`
            : `The engine prevailed by ${over.reason}. Rise again.`;
    } else {
      overlayTitle = over.winner ? `${over.winner === "w" ? "White" : "Black"} Triumphs` : "A Draw";
      overlaySub = over.winner ? `Decided by ${over.reason} in ${Math.ceil(history.length / 2)} moves.` : `By ${over.reason}.`;
    }
  }

  function PlayerBar({ color }) {
    const adv = color === "w" ? diff : -diff;
    return (
      <div className={`player-bar ${turn === color && !over ? "to-move" : ""}`}>
        <span className={`player-token token-${color}`}>{color === "w" ? "♔" : "♚"}</span>
        <span className="player-name">{nameFor(color)}</span>
        <span className="captures">
          {captured[color].map((p, i) => (
            <span key={i} className={`cap piece-${color === "w" ? "b" : "w"}`}>{GLYPH[p]}</span>
          ))}
          {adv > 0 && <b>+{adv}</b>}
        </span>
        {turn === color && !over && <span className="turn-dot" />}
      </div>
    );
  }

  return (
    <main className="chess-game">
      <header className="chess-game-header">
        <button onClick={onBack} className="chess-ghost">← Leave arena</button>
        <div className="title-block">
          <p className="chess-eyebrow">{mode === "ai" ? "VERSUS THE MACHINE" : "LOCAL DUEL"}</p>
          <h1>{mode === "ai" ? LEVELS.find((l) => l.id === difficulty)?.name + " Match" : "Classic Match"}</h1>
        </div>
        <div className="header-tools">
          <button
            className="icon-btn"
            title={muted ? "Unmute" : "Mute"}
            aria-label={muted ? "Unmute sounds" : "Mute sounds"}
            onClick={() => {
              sound.setMuted(!muted);
              setMuted(!muted);
            }}
          >
            {muted ? "🔇︎" : "♪"}
          </button>
          <button className="icon-btn" title="Flip board" aria-label="Flip board" onClick={() => setFlipped((f) => !f)}>⇅</button>
        </div>
      </header>

      <section className="chess-layout">
        <div className="eval-bar" aria-label="Position evaluation" title="Position evaluation">
          <div className="eval-white" style={{ height: `${whiteShare}%`, [flipView ? "top" : "bottom"]: 0 }} />
          <span className={`eval-num ${evalScore >= 0 ? (flipView ? "at-top" : "at-bottom") : flipView ? "at-bottom" : "at-top"}`}>
            {over ? (over.winner ? "#" : "½") : (Math.abs(evalScore) / 100).toFixed(1)}
          </span>
        </div>

        <div className="chess-board-wrap">
          <PlayerBar color={topColor} />

          <div className={`chess-board-frame ${thinking ? "is-thinking" : ""}`}>
            <div className="chess-board" onDragEnd={() => setDragFrom(null)}>
              {rows.map((r) =>
                cols.map((c) => {
                  const square = FILES[c] + (8 - r);
                  const piece = board[r][c];
                  const light = (r + c) % 2 === 0;
                  const target = legalTargets.get(square);
                  const isLast = lastMove && (lastMove.from === square || lastMove.to === square);
                  const isHint = hint && !hint.loading && (hint.from === square || hint.to === square);
                  const showRank = cols.indexOf(c) === 0;
                  const showFile = rows.indexOf(r) === 7;
                  const animate = lastMove && lastMove.to === square;
                  return (
                    <button
                      key={square}
                      aria-label={`${square}${piece ? `, ${piece.color === "w" ? "white" : "black"} ${PIECE_NAME[piece.type]}` : ""}`}
                      className={[
                        "chess-square",
                        light ? "light-square" : "dark-square",
                        selected === square ? "selected-square" : "",
                        isLast ? "last-square" : "",
                        isHint ? "hint-square" : "",
                        kingInCheck === square ? "check-square" : "",
                        target ? (target.captured ? "capture-target" : "move-target") : "",
                      ].join(" ")}
                      onClick={() => onSquare(square)}
                      onDragOver={(e) => {
                        if (dragFrom) e.preventDefault();
                      }}
                      onDrop={(e) => {
                        e.preventDefault();
                        if (dragFrom && dragFrom !== square) tryMove(dragFrom, square);
                        setDragFrom(null);
                      }}
                    >
                      {piece && (
                        <span
                          className="piece-holder"
                          draggable={!locked && piece.color === turn}
                          onDragStart={(e) => {
                            if (locked || piece.color !== turn) return e.preventDefault();
                            e.dataTransfer.effectAllowed = "move";
                            setSelected(square);
                            setDragFrom(square);
                          }}
                        >
                          <Piece
                            key={animate ? `m${history.length}` : "s"}
                            piece={piece}
                            className={animate ? "slide-in" : ""}
                            style={animate ? animOffset : undefined}
                          />
                        </span>
                      )}
                      {showRank && <small className="rank-label">{8 - r}</small>}
                      {showFile && <small className="file-label">{FILES[c]}</small>}
                    </button>
                  );
                })
              )}
            </div>

            {promotion && (
              <div className="promotion-veil">
                <p>Promote to</p>
                <div>
                  {["q", "r", "b", "n"].map((type) => (
                    <button key={type} onClick={() => commit({ from: promotion.from, to: promotion.to, promotion: type })} aria-label={PIECE_NAME[type]}>
                      <Piece piece={{ type, color: turn }} />
                    </button>
                  ))}
                </div>
                <button className="chess-ghost" onClick={() => setPromotion(null)}>Cancel</button>
              </div>
            )}

            {over && overlayOpen && (
              <div className="game-over">
                <div className="letterbox top" />
                <div className="game-over-content">
                  <p className="chess-eyebrow">{over.reason.toUpperCase()}</p>
                  <h2>{overlayTitle}</h2>
                  <p>{overlaySub}</p>
                  {saveState === "saved" && <span className="saved-pill">✓ Saved to your legacy</span>}
                  {saveState === "error" && <span className="saved-pill warn">Couldn't save this game</span>}
                  {!token && <span className="saved-pill">Sign in to record your games</span>}
                  <div className="game-over-actions">
                    <button className="chess-primary" onClick={restart}>Rematch</button>
                    <button className="chess-ghost" onClick={onNewSetup}>New setup</button>
                    <button className="chess-ghost" onClick={() => setOverlayOpen(false)}>Review board</button>
                  </div>
                </div>
                <div className="letterbox bottom" />
              </div>
            )}
          </div>

          <PlayerBar color={bottomColor} />
        </div>

        <aside className="chess-info">
          <p className="chess-eyebrow">{over ? "FINAL" : "LIVE MATCH"}</p>
          <h2 className={game.isCheck() && !over ? "in-check" : ""}>{status}</h2>
          <p className="chess-muted">
            {mode === "ai" ? `You play ${playerColor === "w" ? "White" : "Black"} · Move ${Math.floor(history.length / 2) + 1}` : `Two players · Same screen · Move ${Math.floor(history.length / 2) + 1}`}
          </p>
          {thinking && (
            <div className="thinking">
              <span /><span /><span />
            </div>
          )}
          {hint && (
            <p className="hint-text">
              {hint.loading ? "Consulting the oracle…" : <>Consider <b>{hint.san}</b></>}
            </p>
          )}

          <h3>Move History</h3>
          <div className="chess-move-list">
            {history.length === 0 ? (
              <p className="chess-muted">The board awaits the first move…</p>
            ) : (
              Array.from({ length: Math.ceil(history.length / 2) }, (_, i) => (
                <div className="chess-move-row" key={i}>
                  <span>{i + 1}.</span>
                  <span className={i * 2 === history.length - 1 ? "latest" : ""}>{history[i * 2].san}</span>
                  <span className={i * 2 + 1 === history.length - 1 ? "latest" : ""}>{history[i * 2 + 1]?.san || ""}</span>
                </div>
              )).reverse()
            )}
          </div>

          <div className="chess-actions">
            <button className="chess-ghost" onClick={undo} disabled={!history.length || thinking || Boolean(over)}>Undo</button>
            <button className="chess-ghost" onClick={showHint} disabled={locked}>Hint</button>
            <button className="chess-ghost danger" onClick={() => !over && history.length && setResigned(mode === "ai" ? playerColor : turn)} disabled={Boolean(over) || !history.length}>Resign</button>
            <button className="chess-primary" onClick={restart}>Restart</button>
          </div>
          {over && !overlayOpen && (
            <button className="chess-ghost wide" onClick={() => setOverlayOpen(true)}>Show result</button>
          )}
        </aside>
      </section>
    </main>
  );
}

export default function ChessGame({ token, onBack, onSaved, initialConfig }) {
  const [config, setConfig] = useState(initialConfig || null);
  const [round, setRound] = useState(0);

  if (!config) {
    return (
      <>
        <div className="game-backdrop" aria-hidden="true" />
        <Setup initial={initialConfig} onBack={onBack} onStart={(c) => { setConfig(c); setRound((r) => r + 1); }} />
      </>
    );
  }
  return (
    <>
      <div className="game-backdrop" aria-hidden="true" />
      <Match
      key={round}
      config={config}
      token={token}
      onBack={onBack}
      onSaved={onSaved}
      onNewSetup={() => setConfig(null)}
    />
    </>
  );
}
