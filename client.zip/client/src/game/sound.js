// Tiny synthesized sound kit (no audio files needed).
let ctx = null;
let muted = false;

try {
  muted = localStorage.getItem("chessArenaMuted") === "1";
} catch {
  /* storage unavailable */
}

function audio() {
  if (muted) return null;
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function knock(freq, duration, gain = 0.35, type = "triangle") {
  const ac = audio();
  if (!ac) return;
  const t = ac.currentTime;
  const osc = ac.createOscillator();
  const g = ac.createGain();
  const filter = ac.createBiquadFilter();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  osc.frequency.exponentialRampToValueAtTime(freq * 0.55, t + duration);
  filter.type = "lowpass";
  filter.frequency.value = 1800;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.005);
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
  osc.connect(filter).connect(g).connect(ac.destination);
  osc.start(t);
  osc.stop(t + duration + 0.02);
}

function tone(freq, start, duration, gain = 0.12) {
  const ac = audio();
  if (!ac) return;
  const t = ac.currentTime + start;
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = "sine";
  osc.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
  osc.connect(g).connect(ac.destination);
  osc.start(t);
  osc.stop(t + duration + 0.05);
}

export const sound = {
  move: () => knock(420, 0.09),
  capture: () => {
    knock(300, 0.12, 0.45);
    setTimeout(() => knock(520, 0.06, 0.2), 35);
  },
  check: () => {
    tone(880, 0, 0.25, 0.08);
    tone(1320, 0.05, 0.3, 0.05);
  },
  start: () => {
    [261.6, 329.6, 392, 523.3].forEach((f, i) => tone(f, i * 0.09, 0.6, 0.06));
  },
  end: (won = true) => {
    const notes = won ? [392, 493.9, 587.3, 784] : [392, 349.2, 311.1, 261.6];
    notes.forEach((f, i) => tone(f, i * 0.16, 0.9, 0.08));
  },
  isMuted: () => muted,
  setMuted: (value) => {
    muted = value;
    try {
      localStorage.setItem("chessArenaMuted", value ? "1" : "0");
    } catch {
      /* storage unavailable */
    }
  },
};
