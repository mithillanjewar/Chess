// A compact alpha-beta chess engine built on chess.js.
// Runs inside a Web Worker (see engine.worker.js) so the UI never freezes.
import { Chess } from "chess.js";

const VALUE = { p: 100, n: 320, b: 335, r: 500, q: 920, k: 0 };

// Piece-square tables from White's point of view (a8 first, h1 last).
const PST = {
  p: [
    0, 0, 0, 0, 0, 0, 0, 0,
    60, 60, 60, 60, 60, 60, 60, 60,
    12, 14, 22, 32, 32, 22, 14, 12,
    6, 6, 12, 26, 26, 12, 6, 6,
    0, 0, 6, 22, 22, 6, 0, 0,
    6, -4, -8, 2, 2, -8, -4, 6,
    6, 10, 10, -22, -22, 10, 10, 6,
    0, 0, 0, 0, 0, 0, 0, 0,
  ],
  n: [
    -50, -38, -30, -30, -30, -30, -38, -50,
    -38, -18, 0, 2, 2, 0, -18, -38,
    -30, 2, 12, 16, 16, 12, 2, -30,
    -30, 6, 16, 22, 22, 16, 6, -30,
    -30, 2, 16, 22, 22, 16, 2, -30,
    -30, 6, 12, 16, 16, 12, 6, -30,
    -38, -18, 0, 6, 6, 0, -18, -38,
    -50, -36, -30, -30, -30, -30, -36, -50,
  ],
  b: [
    -20, -10, -10, -10, -10, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 6, 10, 10, 6, 0, -10,
    -10, 6, 6, 10, 10, 6, 6, -10,
    -10, 0, 10, 10, 10, 10, 0, -10,
    -10, 10, 10, 10, 10, 10, 10, -10,
    -10, 6, 0, 0, 0, 0, 6, -10,
    -20, -10, -12, -10, -10, -12, -10, -20,
  ],
  r: [
    0, 0, 0, 0, 0, 0, 0, 0,
    6, 12, 12, 12, 12, 12, 12, 6,
    -6, 0, 0, 0, 0, 0, 0, -6,
    -6, 0, 0, 0, 0, 0, 0, -6,
    -6, 0, 0, 0, 0, 0, 0, -6,
    -6, 0, 0, 0, 0, 0, 0, -6,
    -6, 0, 0, 0, 0, 0, 0, -6,
    0, 0, 2, 8, 8, 4, 0, 0,
  ],
  q: [
    -20, -10, -10, -5, -5, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 5, 5, 5, 0, -10,
    -5, 0, 5, 5, 5, 5, 0, -5,
    0, 0, 5, 5, 5, 5, 0, -5,
    -10, 5, 5, 5, 5, 5, 0, -10,
    -10, 0, 5, 0, 0, 0, 0, -10,
    -20, -10, -10, -5, -5, -10, -10, -20,
  ],
  k: [
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -20, -30, -30, -40, -40, -30, -30, -20,
    -10, -20, -20, -20, -20, -20, -20, -10,
    16, 16, 0, 0, 0, 0, 16, 16,
    20, 32, 12, 0, 0, 12, 32, 20,
  ],
  kEnd: [
    -50, -40, -30, -20, -20, -30, -40, -50,
    -30, -20, -10, 0, 0, -10, -20, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -30, 0, 0, 0, 0, -30, -30,
    -50, -30, -30, -30, -30, -30, -30, -50,
  ],
};

const MATE = 100000;

/** Static evaluation from White's perspective (centipawns). */
export function evaluate(game) {
  const board = game.board();
  let score = 0;
  let nonPawnMaterial = 0;

  for (const rank of board) {
    for (const piece of rank) {
      if (piece && piece.type !== "p" && piece.type !== "k") nonPawnMaterial += VALUE[piece.type];
    }
  }
  const endgame = nonPawnMaterial <= 2600;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;
      const table = piece.type === "k" && endgame ? PST.kEnd : PST[piece.type];
      const index = piece.color === "w" ? r * 8 + c : (7 - r) * 8 + c;
      const value = VALUE[piece.type] + table[index];
      score += piece.color === "w" ? value : -value;
    }
  }
  return score;
}

function orderMoves(moves) {
  return moves
    .map((m) => {
      let s = 0;
      if (m.captured) s += 10 * VALUE[m.captured] - VALUE[m.piece];
      if (m.promotion) s += VALUE[m.promotion];
      if (m.san.includes("+")) s += 50;
      return [s, m];
    })
    .sort((a, b) => b[0] - a[0])
    .map((x) => x[1]);
}

function quiesce(game, alpha, beta, color, depth) {
  const stand = color * evaluate(game);
  if (depth === 0) return stand;
  if (stand >= beta) return beta;
  if (stand > alpha) alpha = stand;

  const captures = orderMoves(game.moves({ verbose: true }).filter((m) => m.captured));
  for (const move of captures) {
    game.move(move);
    const score = -quiesce(game, -beta, -alpha, -color, depth - 1);
    game.undo();
    if (score >= beta) return beta;
    if (score > alpha) alpha = score;
  }
  return alpha;
}

function negamax(game, depth, alpha, beta, color, ply) {
  if (game.isCheckmate()) return -MATE + ply;
  if (game.isDraw()) return 0;
  if (depth === 0) return quiesce(game, alpha, beta, color, 3);

  const moves = orderMoves(game.moves({ verbose: true }));
  let best = -Infinity;
  for (const move of moves) {
    game.move(move);
    const score = -negamax(game, depth - 1, -beta, -alpha, -color, ply + 1);
    game.undo();
    if (score > best) best = score;
    if (score > alpha) alpha = score;
    if (alpha >= beta) break;
  }
  return best;
}

const LEVELS = {
  easy: { depth: 1, noise: 120 },
  medium: { depth: 2, noise: 25 },
  hard: { depth: 3, noise: 0 },
};

/** Returns the chosen move as { from, to, promotion } or null. */
export function findBestMove(fen, level = "medium") {
  const { depth, noise } = LEVELS[level] || LEVELS.medium;
  const game = new Chess(fen);
  const color = game.turn() === "w" ? 1 : -1;
  const moves = orderMoves(game.moves({ verbose: true }));
  if (!moves.length) return null;

  let bestScore = -Infinity;
  let bestMove = moves[0];
  let alpha = -Infinity;
  const beta = Infinity;

  let bestRaw = -Infinity;
  for (const move of moves) {
    game.move(move);
    const raw = -negamax(game, depth - 1, -beta, -alpha, -color, 1);
    game.undo();
    // Noise makes lower levels feel human; only moves near the best can win the coin-flip.
    const score = noise ? raw + (Math.random() - 0.5) * noise * 2 : raw;
    if (score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
    if (raw > bestRaw) {
      bestRaw = raw;
      alpha = Math.max(alpha, bestRaw - noise * 2);
    }
  }

  return { from: bestMove.from, to: bestMove.to, promotion: bestMove.promotion, san: bestMove.san };
}
