import { findBestMove } from "./engine.js";

self.onmessage = (event) => {
  const { id, fen, level } = event.data;
  try {
    const move = findBestMove(fen, level);
    self.postMessage({ id, move });
  } catch (error) {
    self.postMessage({ id, move: null, error: String(error) });
  }
};
