import { useEffect, useState } from "react";
import { api } from "../api.js";
import { Embers, useReveal } from "./effects.jsx";

const LEVEL_NAME = { easy: "Squire", medium: "Knight", hard: "Grandmaster" };

function formatDate(value) {
  if (!value) return "—";
  const d = new Date(value.includes("T") ? value : value.replace(" ", "T") + "Z");
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

function TopBar({ user, admin, onSignOut, onHome }) {
  return (
    <header className="dash-topbar">
      <button className="brand brand-btn" onClick={onHome}>
        <span className="brand-mark">♞</span>
        <span>CHESS <b>ARENA</b></span>
      </button>
      <div className="account">
        <span className={`avatar ${admin ? "admin-avatar" : ""}`}>{admin ? "♛" : (user.username || "P").slice(0, 1).toUpperCase()}</span>
        <span className="account-name">{user.username || user.email}</span>
        <button className="outline-button" onClick={onSignOut}>Sign out</button>
      </div>
    </header>
  );
}

function resultLabel(g) {
  if (g.mode === "ai") return { win: "Victory", loss: "Defeat", draw: "Draw" }[g.result];
  return { white: "White won", black: "Black won", draw: "Draw" }[g.result];
}

/* ====================== Player ====================== */

export function UserDashboard({ user, token, onSignOut, onPlay, refreshKey }) {
  const [section, setSection] = useState("overview");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  useReveal([section, data]);

  useEffect(() => {
    let alive = true;
    api("/games/me", { token })
      .then((d) => alive && setData(d))
      .catch((e) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, [token, refreshKey]);

  const stats = data?.stats || { played: 0, wins: 0, losses: 0, draws: 0 };
  const aiGames = data?.games?.filter((g) => g.mode === "ai") || [];
  const decided = aiGames.filter((g) => g.result !== "draw").length;
  const winRate = decided ? Math.round((aiGames.filter((g) => g.result === "win").length / decided) * 100) : 0;

  let streak = 0;
  for (const g of aiGames) {
    if (g.result === "win") streak++;
    else break;
  }

  const rank =
    stats.wins >= 50 ? "Grandmaster" : stats.wins >= 20 ? "Master" : stats.wins >= 8 ? "Knight" : stats.wins >= 2 ? "Squire" : "Pawn";

  return (
    <main className="dashboard">
      <Embers density={30} />
      <TopBar user={user} onSignOut={onSignOut} onHome={() => setSection("overview")} />

      <section className="dash-welcome">
        <div className="kicker">PLAYER DASHBOARD</div>
        <h1>Welcome back, <span>{user.username || "Player"}</span>.</h1>
        <p className="muted">Rank: <b className="rank-badge">{rank}</b> · Your next great move starts here.</p>
      </section>

      <nav className="dash-nav">
        {["overview", "matches", "profile"].map((item) => (
          <button key={item} className={section === item ? "nav-item active" : "nav-item"} onClick={() => setSection(item)}>
            {item[0].toUpperCase() + item.slice(1)}
          </button>
        ))}
      </nav>

      {error && <p className="error dash-error">{error}</p>}

      {section === "overview" && (
        <>
          <div className="play-grid">
            <button className="play-card featured" data-reveal onClick={() => onPlay({ mode: "ai", difficulty: "medium", color: "w" })}>
              <span className="play-glyph">♛</span>
              <span className="kicker">QUICK MATCH</span>
              <strong>Challenge the Knight</strong>
              <small>Medium engine · You play White</small>
              <i>Play →</i>
            </button>
            <button className="play-card" data-reveal onClick={() => onPlay(null)}>
              <span className="play-glyph">♜</span>
              <span className="kicker">CUSTOM</span>
              <strong>Choose your battle</strong>
              <small>Pick mode, difficulty and colour</small>
              <i>Set up →</i>
            </button>
            <button className="play-card" data-reveal onClick={() => onPlay({ mode: "local" })}>
              <span className="play-glyph">⚔</span>
              <span className="kicker">LOCAL DUEL</span>
              <strong>Face a friend</strong>
              <small>Two players · one screen</small>
              <i>Duel →</i>
            </button>
          </div>

          <div className="stats-grid">
            <article className="stat-card" data-reveal><span className="stat-icon">♟</span><p className="muted">Games played</p><h2>{stats.played}</h2><small>All modes</small></article>
            <article className="stat-card" data-reveal><span className="stat-icon">♔</span><p className="muted">Victories vs engine</p><h2 className="healthy">{stats.wins}</h2><small>{stats.losses} {stats.losses === 1 ? "defeat" : "defeats"} · {stats.draws} {stats.draws === 1 ? "draw" : "draws"}</small></article>
            <article className="stat-card" data-reveal><span className="stat-icon">✦</span><p className="muted">Win rate</p><h2>{winRate}%</h2><small>{streak > 1 ? `${streak}-game win streak` : "Last 25 engine games"}</small></article>
          </div>

          <RecentGames games={data?.games?.slice(0, 5)} loading={!data && !error} onMore={() => setSection("matches")} />
        </>
      )}

      {section === "matches" && <RecentGames games={data?.games} loading={!data && !error} full />}

      {section === "profile" && (
        <section className="feature-card details-card" data-reveal>
          <div className="kicker">YOUR ACCOUNT</div>
          <h2>Player profile</h2>
          <dl>
            <dt>Username</dt><dd>{user.username || "—"}</dd>
            <dt>Email</dt><dd>{user.email || "—"}</dd>
            <dt>Account type</dt><dd>Player</dd>
            <dt>Arena rank</dt><dd>{rank}</dd>
            <dt>Member since</dt><dd>{formatDate(user.created_at)}</dd>
          </dl>
        </section>
      )}

      <footer className="footer">CHESS ARENA <span>•</span> THINK. PLAN. PLAY.</footer>
    </main>
  );
}

function RecentGames({ games, loading, full, onMore }) {
  return (
    <section className="feature-card games-card" data-reveal>
      <div className="games-head">
        <div>
          <div className="kicker">{full ? "GAME CENTER" : "RECENT BATTLES"}</div>
          <h2>{full ? "Match history" : "Your latest games"}</h2>
        </div>
        {!full && games?.length > 0 && <button className="outline-button" onClick={onMore}>View all</button>}
      </div>
      {loading ? (
        <p className="muted">Loading your games…</p>
      ) : !games?.length ? (
        <p className="muted">No games recorded yet. Finish a match while signed in and it will appear here.</p>
      ) : (
        <div className="games-table" role="table">
          {games.map((g) => (
            <div className="games-row" role="row" key={g.id}>
              <span className={`result-chip r-${g.result}`}>{resultLabel(g)}</span>
              <span>{g.mode === "ai" ? `vs ${LEVEL_NAME[g.difficulty]}` : "Local duel"}</span>
              <span className="muted">{g.mode === "ai" ? (g.playerColor === "w" ? "as White" : "as Black") : "—"}</span>
              <span className="muted">{g.reason}</span>
              <span className="muted">{Math.ceil(g.moves / 2)} moves</span>
              <span className="muted">{formatDate(g.createdAt)}</span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

/* ====================== Admin ====================== */

export function AdminDashboard({ user, token, onSignOut, onPlay }) {
  const [section, setSection] = useState("overview");
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState(null);
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  useReveal([section, stats, users]);

  useEffect(() => {
    api("/admin/stats", { token }).then(setStats).catch((e) => setError(e.message));
    api("/admin/users", { token }).then((d) => setUsers(d.users)).catch((e) => setError(e.message));
  }, [token]);

  const filtered = (users || []).filter(
    (u) => !query || u.username.toLowerCase().includes(query.toLowerCase()) || (u.email || "").toLowerCase().includes(query.toLowerCase())
  );

  return (
    <main className="dashboard">
      <Embers density={25} />
      <TopBar user={user} admin onSignOut={onSignOut} onHome={() => setSection("overview")} />

      <section className="dash-welcome">
        <div className="kicker">ADMINISTRATION</div>
        <h1>Control <span>Center.</span></h1>
        <p className="muted">Oversee the Chess Arena from one place.</p>
      </section>

      <nav className="dash-nav">
        {["overview", "players", "settings"].map((item) => (
          <button key={item} className={section === item ? "nav-item active" : "nav-item"} onClick={() => setSection(item)}>
            {item[0].toUpperCase() + item.slice(1)}
          </button>
        ))}
      </nav>

      {error && <p className="error dash-error">{error}</p>}

      {section === "overview" && (
        <>
          <div className="stats-grid four">
            <article className="stat-card" data-reveal><span className="stat-icon">♙</span><p className="muted">Player accounts</p><h2>{stats?.players ?? "—"}</h2><small>+{stats?.newPlayersThisWeek ?? 0} this week</small></article>
            <article className="stat-card" data-reveal><span className="stat-icon">♟</span><p className="muted">Games recorded</p><h2>{stats?.games ?? "—"}</h2><small>All time</small></article>
            <article className="stat-card" data-reveal><span className="stat-icon">♞</span><p className="muted">Last 24 hours</p><h2>{stats?.gamesToday ?? "—"}</h2><small>Games finished</small></article>
            <article className="stat-card" data-reveal><span className="stat-icon">♜</span><p className="muted">System status</p><h2 className="healthy">{stats ? "Online" : "…"}</h2><small>API responding</small></article>
          </div>
          <section className="feature-card admin-note" data-reveal>
            <div className="kicker">ADMIN TOOLS</div>
            <h2>Newest players</h2>
            <UserTable users={users?.slice(0, 5)} />
            <div className="row-actions">
              <button className="outline-button" onClick={() => setSection("players")}>Open player management</button>
              <button className="outline-button" onClick={() => onPlay(null)}>Test the board</button>
            </div>
          </section>
        </>
      )}

      {section === "players" && (
        <section className="feature-card" data-reveal>
          <div className="games-head">
            <div>
              <div className="kicker">PLAYER MANAGEMENT</div>
              <h2>All accounts</h2>
            </div>
            <input className="search" placeholder="Search username or email…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <UserTable users={filtered} />
        </section>
      )}

      {section === "settings" && (
        <section className="feature-card details-card" data-reveal>
          <div className="kicker">SYSTEM</div>
          <h2>Settings</h2>
          <dl>
            <dt>Signed-in account</dt><dd>{user.username || user.email}</dd>
            <dt>Role</dt><dd>Administrator</dd>
            <dt>Authentication</dt><dd>JWT (2-hour sessions)</dd>
            <dt>Database</dt><dd>SQLite · users &amp; games</dd>
          </dl>
          <p className="muted">Keep the JWT secret private and change any temporary development secret before deployment.</p>
        </section>
      )}

      <footer className="footer">CHESS ARENA <span>•</span> ADMINISTRATION</footer>
    </main>
  );
}

function UserTable({ users }) {
  if (!users) return <p className="muted">Loading players…</p>;
  if (!users.length) return <p className="muted">No accounts found.</p>;
  return (
    <div className="games-table">
      {users.map((u) => (
        <div className="games-row users" key={u.id}>
          <span className="user-cell">
            <span className={`avatar small ${u.role === "admin" ? "admin-avatar" : ""}`}>{u.role === "admin" ? "♛" : u.username[0].toUpperCase()}</span>
            {u.username}
          </span>
          <span className="muted">{u.email || "—"}</span>
          <span className={`result-chip ${u.role === "admin" ? "r-admin" : "r-draw"}`}>{u.role}</span>
          <span className="muted">{u.games} games · {u.wins} wins</span>
          <span className="muted">{formatDate(u.createdAt)}</span>
        </div>
      ))}
    </div>
  );
}
