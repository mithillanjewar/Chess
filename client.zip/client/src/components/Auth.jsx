import { useState } from "react";
import { api } from "../api.js";

function LoginPanel({ role, onLogin, onRegister }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setMessage("");
    setLoading(true);
    try {
      const data = await api("/auth/login", {
        method: "POST",
        token: null,
        body: { identifier: identifier.trim(), password, role },
      });
      if (!data.user || data.user.role !== role) throw new Error("The account role does not match this login.");
      onLogin(data);
    } catch (error) {
      setMessage(error.message || "Sign-in failed. Check your details.");
    } finally {
      setLoading(false);
    }
  }

  const admin = role === "admin";
  return (
    <form className="form" onSubmit={submit} key={role}>
      <div className="form-head">
        <div className="kicker">{admin ? "CONTROL ROOM" : "WELCOME BACK"}</div>
        <h2>{admin ? "Administrator access" : "Return to the arena"}</h2>
        <p className="muted">{admin ? "Sign in with your administrator account." : "Sign in to track your games and climb your legacy."}</p>
      </div>
      <label>
        Email or username
        <input value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder="Enter email or username" autoComplete="username" required />
      </label>
      <label>
        Password
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" autoComplete="current-password" required />
      </label>
      {message && <p className="error" role="alert">{message}</p>}
      <button className="primary" disabled={loading}>
        {loading ? "Signing in…" : admin ? "Enter control room" : "Enter the arena"}
      </button>
      {!admin && (
        <p className="small">
          New to Chess Arena?{" "}
          <button className="link" type="button" onClick={onRegister}>Create an account</button>
        </p>
      )}
    </form>
  );
}

function RegisterPanel({ onBack, onRegistered }) {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const strength = Math.min(
    4,
    (password.length >= 8) + (password.length >= 12) + /[A-Z]/.test(password) + /[^a-zA-Z0-9]/.test(password) + /\d/.test(password) - 1
  );

  async function submit(event) {
    event.preventDefault();
    setMessage("");
    setSuccess(false);
    if (password.length < 8) return setMessage("Use a password with at least 8 characters.");
    if (password !== confirm) return setMessage("The passwords do not match.");
    setLoading(true);
    try {
      await api("/auth/register", {
        method: "POST",
        token: null,
        body: { username: username.trim(), email: email.trim(), password },
      });
      setSuccess(true);
      setMessage("Account created! You can now sign in.");
      onRegistered({ username: username.trim(), email: email.trim() });
      setPassword("");
      setConfirm("");
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="form" onSubmit={submit}>
      <div className="form-head">
        <div className="kicker">JOIN THE ARENA</div>
        <h2>Forge your legend</h2>
        <p className="muted">Create a player account. Admin accounts are created separately.</p>
      </div>
      <label>
        Username
        <input value={username} onChange={(e) => setUsername(e.target.value)} minLength={3} maxLength={30} pattern="[A-Za-z0-9_]+" title="Letters, numbers and underscores" placeholder="Choose a username" autoComplete="username" required />
      </label>
      <label>
        Email address
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required />
      </label>
      <div className="form-row">
        <label>
          Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} maxLength={72} placeholder="8+ characters" autoComplete="new-password" required />
        </label>
        <label>
          Confirm
          <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} minLength={8} maxLength={72} placeholder="Repeat password" autoComplete="new-password" required />
        </label>
      </div>
      {password && (
        <div className={`strength s${Math.max(0, strength)}`} aria-label="Password strength">
          <span /><span /><span /><span />
          <em>{["Weak", "Fair", "Good", "Strong", "Formidable"][Math.max(0, strength)]}</em>
        </div>
      )}
      {message && <p className={success ? "success-message" : "error"} role="alert">{message}</p>}
      {success ? (
        <button className="primary" type="button" onClick={onBack}>Go to sign in</button>
      ) : (
        <button className="primary" disabled={loading}>{loading ? "Creating account…" : "Create account"}</button>
      )}
      <p className="small">
        Already registered? <button className="link" type="button" onClick={onBack}>Back to sign in</button>
      </p>
    </form>
  );
}

export default function AuthSection({ onLogin, onGuest }) {
  const [tab, setTab] = useState("user");
  const [registering, setRegistering] = useState(false);
  const [registered, setRegistered] = useState(null);

  return (
    <section className="auth-section" id="enter">
      <div className="auth-copy" data-reveal>
        <p className="kicker">THE GATES ARE OPEN</p>
        <h2 className="section-title">Step into <em>the arena.</em></h2>
        <p className="lead">
          Sign in to record every victory, review your history and watch your legacy grow. Or skip the
          ceremony and play right now as a guest.
        </p>
        <ul className="perks">
          <li><span>♜</span> Every finished game saved to your profile</li>
          <li><span>♝</span> Win, loss and draw record across all difficulties</li>
          <li><span>♛</span> Secure accounts with hashed passwords &amp; tokens</li>
        </ul>
        <button className="outline-button big" onClick={onGuest}>Play as guest →</button>
      </div>

      <div className="auth-card" data-reveal>
        {!registering && (
          <div className="auth-tabs" role="tablist">
            <button role="tab" aria-selected={tab === "user"} className={tab === "user" ? "active" : ""} onClick={() => setTab("user")}>Player</button>
            <button role="tab" aria-selected={tab === "admin"} className={tab === "admin" ? "active" : ""} onClick={() => setTab("admin")}>Admin</button>
            <span className="tab-ink" style={{ transform: `translateX(${tab === "user" ? 0 : 100}%)` }} />
          </div>
        )}
        <div className="auth-body" key={registering ? "reg" : tab}>
          {registering ? (
            <RegisterPanel onBack={() => { setRegistering(false); setTab("user"); }} onRegistered={setRegistered} />
          ) : (
            <LoginPanel role={tab} onLogin={onLogin} onRegister={() => setRegistering(true)} />
          )}
        </div>
        {registered && !registering && (
          <p className="registration-reminder">
            Account created for <strong>{registered.email}</strong>. Sign in with your new username or email.
          </p>
        )}
      </div>
    </section>
  );
}
