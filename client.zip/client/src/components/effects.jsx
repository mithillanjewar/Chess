import { useEffect, useRef, useState } from "react";
import { Chess } from "chess.js";

const prefersReducedMotion = () =>
  typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

/* ---------- Opening title sequence ---------- */
export function CinematicIntro({ onDone }) {
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    const total = prefersReducedMotion() ? 600 : 4200;
    const t1 = setTimeout(() => setLeaving(true), total);
    const t2 = setTimeout(onDone, total + 1100);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onDone]);

  function skip() {
    setLeaving(true);
    setTimeout(onDone, 900);
  }

  const title = "CHESS ARENA";
  return (
    <div className={`intro-overlay ${leaving ? "leaving" : ""}`} onClick={skip} role="presentation">
      <div className="intro-bar top" />
      <div className="intro-stage">
        <div className="intro-ray" />
        <div className="intro-mark">♞</div>
        <h1 className="intro-title" aria-label={title}>
          {title.split("").map((ch, i) => (
            <span key={i} style={{ animationDelay: `${0.9 + i * 0.07}s` }}>
              {ch === " " ? " " : ch}
            </span>
          ))}
        </h1>
        <p className="intro-tag">Every move tells a story</p>
      </div>
      <div className="intro-bar bottom" />
      <button className="intro-skip" onClick={skip}>Skip intro ›</button>
    </div>
  );
}

/* ---------- Floating golden embers ---------- */
export function Embers({ density = 70 }) {
  const ref = useRef(null);

  useEffect(() => {
    if (prefersReducedMotion()) return;
    const canvas = ref.current;
    const ctx = canvas.getContext("2d");
    let w, h, raf;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    function resize() {
      w = canvas.offsetWidth;
      h = canvas.offsetHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener("resize", resize);

    const make = (anywhere) => ({
      x: Math.random() * w,
      y: anywhere ? Math.random() * h : h + 10,
      r: Math.random() * 1.8 + 0.4,
      vy: Math.random() * 0.45 + 0.15,
      vx: (Math.random() - 0.5) * 0.25,
      life: Math.random() * Math.PI * 2,
      hue: 35 + Math.random() * 15,
    });
    const parts = Array.from({ length: density }, () => make(true));

    function frame() {
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";
      for (const p of parts) {
        p.y -= p.vy;
        p.x += p.vx + Math.sin(p.life) * 0.2;
        p.life += 0.02;
        if (p.y < -10) Object.assign(p, make(false));
        const a = 0.35 + Math.sin(p.life * 2) * 0.25;
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5);
        g.addColorStop(0, `hsla(${p.hue}, 90%, 70%, ${a})`);
        g.addColorStop(1, "hsla(40, 90%, 50%, 0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * 5, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(frame);
    }
    frame();
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [density]);

  return <canvas ref={ref} className="embers" aria-hidden="true" />;
}

/* ---------- Reveal on scroll ---------- */
export function useReveal(deps = []) {
  useEffect(() => {
    const els = document.querySelectorAll("[data-reveal]:not(.in)");
    if (!("IntersectionObserver" in window)) {
      els.forEach((el) => el.classList.add("in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -40px 0px" }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

/* ---------- Count-up number ---------- */
export function CountUp({ to, suffix = "", duration = 1800 }) {
  const ref = useRef(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf;
    const io = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      io.disconnect();
      const start = performance.now();
      const tick = (now) => {
        const t = Math.min(1, (now - start) / duration);
        setValue(Math.round(to * (1 - Math.pow(1 - t, 3))));
        if (t < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    });
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [to, duration]);

  return (
    <span ref={ref}>
      {value.toLocaleString("en-IN")}
      {suffix}
    </span>
  );
}

/* ---------- Static mini board from a FEN ---------- */
const GLYPH = { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟︎" };

export function MiniBoard({ fen, highlight = [] }) {
  const board = new Chess(fen).board();
  return (
    <div className="mini-board" aria-hidden="true">
      {board.map((rank, r) =>
        rank.map((piece, c) => {
          const sq = "abcdefgh"[c] + (8 - r);
          return (
            <div
              key={sq}
              className={`mini-sq ${(r + c) % 2 ? "d" : "l"} ${highlight.includes(sq) ? "hl" : ""}`}
            >
              {piece && <span className={`piece piece-${piece.color}`}>{GLYPH[piece.type]}</span>}
            </div>
          );
        })
      )}
    </div>
  );
}

/* ---------- Scroll progress + parallax helpers ---------- */
export function useScrollY() {
  const [y, setY] = useState(0);
  useEffect(() => {
    let raf = 0;
    const on = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setY(window.scrollY));
    };
    window.addEventListener("scroll", on, { passive: true });
    return () => {
      window.removeEventListener("scroll", on);
      cancelAnimationFrame(raf);
    };
  }, []);
  return y;
}
