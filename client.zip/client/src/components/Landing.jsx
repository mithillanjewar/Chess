import { useEffect, useRef, useState } from "react";
import arenaBackground from "../assets/chess/arena-background.avif";
import goldenQueen from "../assets/chess/golden-queen.webp";
import AuthSection from "./Auth.jsx";
import { CountUp, Embers, MiniBoard, useReveal, useScrollY } from "./effects.jsx";

const YEAR = new Date().getFullYear();

const OPENINGS = [
  "Ruy López", "Sicilian Defence", "Queen's Gambit", "King's Indian", "Italian Game", "Caro-Kann",
  "French Defence", "London System", "Nimzo-Indian", "Grünfeld", "English Opening", "Scandinavian",
];

const ACTS = [
  {
    act: "Act I",
    name: "The Opening",
    line: "Claim the centre. Develop with purpose.",
    copy: "The first moves set the stage. Knights leap out, bishops find their diagonals, and the king prepares to hide. Every opening is a promise about the battle to come.",
    fen: "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3",
    highlight: ["c4", "f7"],
    caption: "The Italian Game — the bishop eyes f7",
  },
  {
    act: "Act II",
    name: "The Middlegame",
    line: "Plans collide. Tactics strike.",
    copy: "Here the armies meet. Pins, forks and sacrifices appear from nowhere. One miscalculation and the whole position collapses. This is where games are won.",
    fen: "r2q1rk1/pp2bppp/2n1bn2/3p4/3P4/2NBBN2/PP3PPP/R2Q1RK1 w - - 4 11",
    highlight: ["d3", "h7"],
    caption: "Tension builds — the bishop aims at h7",
  },
  {
    act: "Act III",
    name: "The Endgame",
    line: "Precision is everything.",
    copy: "When the dust settles, few pieces remain and every tempo matters. Kings become warriors, pawns dream of becoming queens, and a single move decides the story.",
    fen: "3R2k1/5ppp/8/8/8/8/5PPP/6K1 b - - 1 1",
    highlight: ["d8", "g8"],
    caption: "Back-rank mate — the curtain falls",
  },
];

const FEATURES = [
  { glyph: "♛", title: "Versus the Machine", copy: "A built-in engine with three personalities — Squire, Knight and Grandmaster. It thinks in a background thread, so the board never freezes." },
  { glyph: "⚔", title: "Local Duels", copy: "Challenge a friend on the same screen. Flip the board, take back moves and settle the score face to face." },
  { glyph: "♜", title: "Your Legacy", copy: "Sign in and every finished game is recorded — wins, losses, draws and how each one ended." },
  { glyph: "✦", title: "Cinematic Board", copy: "Gliding pieces, a live evaluation bar, check alerts, hints, drag-and-drop and a sound design built from scratch." },
];

const TIMELINE = [
  { year: "c. 600", name: "Chaturanga", note: "Chess is born in India — four divisions of an army: infantry, cavalry, elephants and chariots." },
  { year: "c. 800", name: "Shatranj", note: "The game travels to Persia and across the Islamic world. “Shah mat” — the king is helpless — gives us checkmate." },
  { year: "c. 1475", name: "The Mad Queen", note: "In Europe the queen gains her sweeping powers and the modern, faster game is born." },
  { year: "1886", name: "Wilhelm Steinitz", note: "Becomes the first official World Chess Champion." },
  { year: "1894", name: "Emanuel Lasker", note: "Holds the crown for 27 years — the longest reign in history." },
  { year: "1972", name: "Bobby Fischer", note: "Defeats Boris Spassky in Reykjavík in the most famous match of the Cold War." },
  { year: "1985", name: "Garry Kasparov", note: "At 22, becomes the youngest undisputed champion of his time — and reigns until 2000." },
  { year: "2000", name: "Viswanathan Anand", note: "Wins his first world title — India's first World Chess Champion." },
  { year: "2013", name: "Magnus Carlsen", note: "Takes the title from Anand and reaches the highest rating ever recorded." },
  { year: "2024", name: "Gukesh D", note: "At 18, becomes the youngest undisputed World Champion in history." },
];

function Nav({ onPlay, scrolled, progress }) {
  return (
    <header className={`site-nav ${scrolled ? "scrolled" : ""}`}>
      <div className="nav-inner">
        <a className="brand" href="#top">
          <span className="brand-mark">♞</span>
          <span>CHESS <b>ARENA</b></span>
        </a>
        <nav className="nav-links">
          <a href="#story">Story</a>
          <a href="#features">Arena</a>
          <a href="#legends">Legends</a>
          <a href="#enter">Sign in</a>
        </nav>
        <button className="nav-cta" onClick={onPlay}>Play now</button>
      </div>
      <div className="scroll-progress" style={{ transform: `scaleX(${progress})` }} />
    </header>
  );
}

export default function Landing({ onLogin, onGuest }) {
  const y = useScrollY();
  const heroRef = useRef(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  useReveal();

  const docH = typeof document !== "undefined" ? document.documentElement.scrollHeight - window.innerHeight : 1;
  const progress = Math.min(1, y / Math.max(1, docH));

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    const move = (e) => {
      const r = el.getBoundingClientRect();
      setMouse({ x: (e.clientX - r.left) / r.width - 0.5, y: (e.clientY - r.top) / r.height - 0.5 });
    };
    el.addEventListener("pointermove", move);
    return () => el.removeEventListener("pointermove", move);
  }, []);

  const heroFade = Math.max(0, 1 - y / 700);

  return (
    <div className="landing" id="top">
      <Nav onPlay={onGuest} scrolled={y > 40} progress={progress} />

      {/* ---------------- HERO ---------------- */}
      <section className="hero" ref={heroRef}>
        <div
          className="hero-bg"
          style={{
            backgroundImage: `url(${arenaBackground})`,
            transform: `translate3d(${mouse.x * -18}px, ${y * 0.35 + mouse.y * -12}px, 0) scale(1.15)`,
          }}
        />
        <div className="hero-rays" />
        <div className="hero-fog fog-a" />
        <div className="hero-fog fog-b" />
        <Embers />
        <div className="hero-vignette" />

        <div className="hero-inner" style={{ opacity: heroFade, transform: `translateY(${y * 0.15}px)` }}>
          <div className="hero-copy">
            <p className="kicker hero-kicker"><span className="line" /> A GAME OF KINGS, SINCE 600 AD</p>
            <h1 className="hero-title">
              <span className="reveal-line"><span>Every move</span></span>
              <span className="reveal-line"><span>tells <em>a story.</em></span></span>
            </h1>
            <p className="hero-lead">
              Enter a cinematic chess arena. Duel a friend, challenge an engine with three levels of cunning,
              and write your own legend — one move at a time.
            </p>
            <div className="hero-actions">
              <button className="primary hero-btn" onClick={onGuest}>
                <span>Play now</span> <i>→</i>
              </button>
              <a className="ghost-link" href="#enter">Sign in to save games</a>
            </div>
            <div className="hero-meta">
              <div><strong>3</strong><span>AI levels</span></div>
              <div><strong>2</strong><span>Game modes</span></div>
              <div><strong>∞</strong><span>Stories</span></div>
            </div>
          </div>

          <div
            className="hero-queen"
            style={{ transform: `translate3d(${mouse.x * 26}px, ${mouse.y * 18}px, 0) rotateY(${mouse.x * 10}deg)` }}
          >
            <div className="queen-halo" />
            <img src={goldenQueen} alt="A golden chess queen glowing on a dark board" />
            <div className="queen-reflection" />
          </div>
        </div>

        <a className="scroll-cue" href="#story" aria-label="Scroll to story">
          <span>SCROLL</span>
          <i />
        </a>
      </section>

      {/* ---------------- MARQUEE ---------------- */}
      <div className="marquee" aria-hidden="true">
        <div className="marquee-track">
          {[...OPENINGS, ...OPENINGS].map((o, i) => (
            <span key={i}>{o} <b>✦</b></span>
          ))}
        </div>
      </div>

      {/* ---------------- STORY / ACTS ---------------- */}
      <section className="story" id="story">
        <div className="section-head" data-reveal>
          <p className="kicker">A STORY IN THREE ACTS</p>
          <h2 className="section-title">Every game is <em>a film.</em></h2>
          <p className="lead">Opening, middlegame, endgame. Sixty-four squares become a stage, and thirty-two pieces become characters.</p>
        </div>

        <div className="acts">
          {ACTS.map((a, i) => (
            <article className={`act ${i % 2 ? "flip" : ""}`} key={a.act} data-reveal>
              <div className="act-board">
                <MiniBoard fen={a.fen} highlight={a.highlight} />
                <p className="act-caption">{a.caption}</p>
              </div>
              <div className="act-copy">
                <span className="act-num">0{i + 1}</span>
                <p className="kicker">{a.act}</p>
                <h3>{a.name}</h3>
                <p className="act-line">{a.line}</p>
                <p className="muted">{a.copy}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ---------------- FEATURES ---------------- */}
      <section className="features" id="features">
        <div className="section-head" data-reveal>
          <p className="kicker">INSIDE THE ARENA</p>
          <h2 className="section-title">Built for <em>the battle.</em></h2>
        </div>
        <div className="feature-row">
          {FEATURES.map((f, i) => (
            <article className="glow-card" key={f.title} data-reveal style={{ transitionDelay: `${i * 90}ms` }}>
              <span className="glow-glyph">{f.glyph}</span>
              <h3>{f.title}</h3>
              <p className="muted">{f.copy}</p>
            </article>
          ))}
        </div>
      </section>

      {/* ---------------- QUOTE BAND ---------------- */}
      <section className="quote-band">
        <div className="quote-bg" style={{ backgroundImage: `url(${arenaBackground})`, transform: `translateY(${(y - 2400) * 0.12}px) scale(1.2)` }} />
        <div className="quote-inner" data-reveal>
          <span className="quote-glyph">♚</span>
          <p className="quote">“When the game ends, the king and the pawn go back into the same box.”</p>
          <p className="quote-by">— Old proverb</p>
        </div>
      </section>

      {/* ---------------- NUMBERS ---------------- */}
      <section className="numbers">
        <div className="number" data-reveal>
          <strong><CountUp to={64} /></strong>
          <span>squares on the stage</span>
        </div>
        <div className="number" data-reveal>
          <strong><CountUp to={32} /></strong>
          <span>pieces in every story</span>
        </div>
        <div className="number" data-reveal>
          <strong><CountUp to={1400} suffix="+" /></strong>
          <span>years since chaturanga</span>
        </div>
        <div className="number" data-reveal>
          <strong>10<sup>120</sup></strong>
          <span>possible games (Shannon number)</span>
        </div>
      </section>

      {/* ---------------- LEGENDS TIMELINE ---------------- */}
      <section className="legends" id="legends">
        <div className="section-head" data-reveal>
          <p className="kicker">HALL OF LEGENDS</p>
          <h2 className="section-title">From India <em>to the world.</em></h2>
          <p className="lead">Fourteen centuries of kings, queens and the people who mastered them.</p>
        </div>
        <ol className="timeline">
          {TIMELINE.map((t, i) => (
            <li key={t.year} data-reveal className={i % 2 ? "right" : "left"}>
              <div className="tl-card">
                <span className="tl-year">{t.year}</span>
                <h3>{t.name}</h3>
                <p className="muted">{t.note}</p>
              </div>
              <span className="tl-dot" />
            </li>
          ))}
        </ol>
      </section>

      {/* ---------------- AUTH ---------------- */}
      <AuthSection onLogin={onLogin} onGuest={onGuest} />

      {/* ---------------- FINAL CTA ---------------- */}
      <section className="final-cta" data-reveal>
        <h2 className="section-title">The board is set.<br /><em>Your move.</em></h2>
        <button className="primary hero-btn" onClick={onGuest}><span>Begin a match</span> <i>→</i></button>
      </section>

      <footer className="site-footer">
        <div className="brand"><span className="brand-mark">♞</span><span>CHESS <b>ARENA</b></span></div>
        <p>THINK <span>•</span> PLAN <span>•</span> PLAY</p>
        <p className="tiny">© {YEAR} Chess Arena. Crafted for players who love the game.</p>
      </footer>
    </div>
  );
}
