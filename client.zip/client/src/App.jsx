import { useCallback, useEffect, useState } from "react";
import ChessGame from "./ChessGame";
import Landing from "./components/Landing.jsx";
import { AdminDashboard, UserDashboard } from "./components/Dashboards.jsx";
import { CinematicIntro } from "./components/effects.jsx";
import { api, getToken, setToken } from "./api.js";
import "./App.css";

function introSeen() {
  try {
    return sessionStorage.getItem("chessArenaIntro") === "1";
  } catch {
    return false;
  }
}

export default function App() {
  const [user, setUser] = useState(null);
  const [token, setTok] = useState(() => getToken());
  const [checking, setChecking] = useState(() => Boolean(getToken()));
  const [view, setView] = useState("home"); // home | game
  const [gameConfig, setGameConfig] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [showIntro, setShowIntro] = useState(() => !introSeen());
  const [curtain, setCurtain] = useState(false);

  // Keep the session on refresh; the backend verifies the saved token.
  useEffect(() => {
    if (!token) return;
    api("/auth/me", { token })
      .then((data) => setUser(data.user))
      .catch(() => {
        setToken(null);
        setTok(null);
      })
      .finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const endIntro = useCallback(() => {
    setShowIntro(false);
    try {
      sessionStorage.setItem("chessArenaIntro", "1");
    } catch {
      /* ignore */
    }
  }, []);

  // A short black "cut" between scenes.
  function transition(fn) {
    setCurtain(true);
    setTimeout(() => {
      fn();
      window.scrollTo({ top: 0 });
      setTimeout(() => setCurtain(false), 60);
    }, 420);
  }

  function handleLogin(data) {
    transition(() => {
      setToken(data.token);
      setTok(data.token);
      setUser(data.user);
      setView("home");
    });
  }

  function signOut() {
    transition(() => {
      setToken(null);
      setTok(null);
      setUser(null);
      setView("home");
    });
  }

  function play(config) {
    transition(() => {
      setGameConfig(config && config.mode === "ai" && !config.color ? { ...config, color: "w" } : config);
      setView("game");
    });
  }

  function leaveGame() {
    transition(() => setView("home"));
  }

  let screen;
  if (checking) {
    screen = (
      <div className="loading-screen">
        <span className="brand-mark spin">♞</span>
      </div>
    );
  } else if (view === "game") {
    screen = (
      <ChessGame
        token={user ? token : null}
        initialConfig={gameConfig && gameConfig.mode === "local" ? { mode: "local" } : gameConfig}
        onBack={leaveGame}
        onSaved={() => setRefreshKey((k) => k + 1)}
      />
    );
  } else if (user) {
    screen =
      user.role === "admin" ? (
        <AdminDashboard user={user} token={token} onSignOut={signOut} onPlay={play} />
      ) : (
        <UserDashboard user={user} token={token} onSignOut={signOut} onPlay={play} refreshKey={refreshKey} />
      );
  } else {
    screen = <Landing onLogin={handleLogin} onGuest={() => play(null)} />;
  }

  return (
    <>
      <div className="grain" aria-hidden="true" />
      {screen}
      <div className={`scene-cut ${curtain ? "on" : ""}`} aria-hidden="true" />
      {showIntro && !user && !checking && <CinematicIntro onDone={endIntro} />}
    </>
  );
}
